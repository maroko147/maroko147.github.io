import React from 'react';
import { Menu, DollarSign, Briefcase, Users, TrendingUp } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-sm z-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <span className="text-xl font-bold">MMMC Corporation</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-center space-x-8">
                <a href="#about" className="text-gray-600 hover:text-gray-900">ABOUT</a>
                <a href="#work" className="text-gray-600 hover:text-gray-900">WORK</a>
                <a href="#team" className="text-gray-600 hover:text-gray-900">TEAM</a>
                <a href="#blog" className="text-gray-600 hover:text-gray-900">BLOG</a>
                <a href="#contact" className="text-gray-600 hover:text-gray-900">CONTACT</a>
                <button className="bg-black text-white px-6 py-2 rounded-sm hover:bg-gray-800 transition-colors">
                  CONTACT US
                </button>
              </div>
            </div>
            <div className="md:hidden">
              <button className="p-2">
                <Menu className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80"
            alt="Corporate Background" 
            className="w-full h-full object-cover brightness-50"
          />
        </div>
        <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-6xl font-bold text-white mb-6">MMMC Corporation</h1>
          <p className="text-xl text-gray-200 max-w-2xl mb-8">
            We specialize in electrical systems maintenance and much more
          </p>
          <button className="bg-white text-black px-8 py-3 text-lg font-medium hover:bg-gray-100 transition-colors">
            JOIN US NOW!
          </button>
        </div>
      </div>

      {/* What We Believe In Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-16">WHAT WE BELIEVE IN</h2>
          <p className="text-3xl font-light text-gray-600 max-w-4xl mx-auto">
            Grow your business, establish your brand, and put your customers first
          </p>
        </div>
      </div>

      {/* Money Making Methods Section */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 text-center mb-16">Our Revenue Streams</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {/* Method 1 */}
            <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mb-6">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4">Electrical Maintenance</h3>
              <p className="text-gray-600 mb-4">
                Comprehensive electrical system maintenance services for commercial and industrial clients.
                Average monthly revenue: $15,000 - $25,000
              </p>
              <p className="text-sm text-gray-500">Success rate: 95%</p>
            </div>

            {/* Method 2 */}
            <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mb-6">
                <Briefcase className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4">Consulting Services</h3>
              <p className="text-gray-600 mb-4">
                Expert consulting for electrical system optimization and energy efficiency.
                Average monthly revenue: $10,000 - $20,000
              </p>
              <p className="text-sm text-gray-500">Success rate: 90%</p>
            </div>

            {/* Method 3 */}
            <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mb-6">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4">System Integration</h3>
              <p className="text-gray-600 mb-4">
                Modern electrical system integration and automation solutions.
                Average monthly revenue: $20,000 - $35,000
              </p>
              <p className="text-sm text-gray-500">Success rate: 88%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?auto=format&fit=crop&q=80"
                alt="Abstract Geometric Pattern"
                className="w-full rounded-lg shadow-xl"
              />
            </div>
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Team</h2>
              <p className="text-lg text-gray-600 mb-8">
                We are a dedicated team of professionals committed to delivering excellence in electrical systems maintenance. Our expertise spans across various domains, ensuring comprehensive solutions for all your needs.
              </p>
              <button className="bg-black text-white px-8 py-3 text-lg font-medium hover:bg-gray-800 transition-colors">
                LEARN MORE
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;